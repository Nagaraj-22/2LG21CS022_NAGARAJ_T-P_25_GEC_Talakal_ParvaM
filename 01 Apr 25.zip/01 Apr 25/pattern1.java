public class pattern1{
    public static void main(String arg[]) {
        System.out.println("Hello!!!");
    }
}
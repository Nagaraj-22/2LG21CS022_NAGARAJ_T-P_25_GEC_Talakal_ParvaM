package com.example.slmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SlmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
